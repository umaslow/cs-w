<?php

	return array(

	//Header
	'h1' => 'Inici',
	'h2' => 'Projectes',
	'h3' => 'Equip',
	'h4' => 'Serveis',
	'h5' => 'Contacte',

	//Form
	'f1' => 'Email',
	'f2' => 'Contrasenya',
	'f3' => 'Accedir',
	
	//Buttons
	'b1' => 'Més info'

	);

?>