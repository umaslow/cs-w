<?php

	return array(

	//headers
	'h1' => 'Equip de Citysum',

	//intro
	'i1' => 'L’equip de Citysum té un caràcter pluridisciplinar i està format per professionals amb una llarga experiència en el camp de la mobilitat.',

	//text
	't1' => 'Sergi Comellas és Enginyer Industrial amb 15 anys d’experiència en polítiques públiques, en sostenibilitat, mobilitat, mediambient i en eficiència i energies renovables. També és expert en participació, intel·ligència col·lectiva i estratègia d’organitzacions. Actualment combina tasques de consultoria en mobilitat i estratègies d’organitzacions i territoris amb tasca docent a l’Escola Elisava i a ESADE. Dins dels seus àmbits d’especialització, ha organitzat i participat com a ponent en diverses jornades i conferències.',
	't2' => 'Oriol Masllovet és Llicenciat en Sociologia per la UB i compta amb postgraus en Planificació i Gestió de la Mobilitat i en Eficiència Energètica, ambdós cursats en la UPC. La seva experiència laboral es mou sobre el vector de la planificació de la mobilitat i abasta altres camps com és el de la planificació energètica, el de l’avaluació de l’impacte ambiental i el del desenvolupament de models informatitzats. Durant els seus 10 anys com a consultor ha realitzat diversos projectes tant d’àmbit nacional com internacional.',
	't3' => 'Ola Karlsson és llicenciat en Urbanisme i Planificació i Màster en Geografia Humana, ambdues  per la Universitat d´Estocolm. 17 anys d’experiència en la planificació i la gestió de la mobilitat en múltiples projectes nacionals i internacionals.',
	't4' => 'Bernat Goñi és llicenciat en ciències ambientals (UAB) i Master in Science en Transport, Infraestructura i Logística per la Delf University of Technology (Països Baixos) i Màster en Gestió i Valoració Urbana per la UPC i la Cornell University (New York). És expert en la modelització i simulació de trànsit, gestió i control del trànsit i en sistemes de transport intel·ligents, temàtiques en les que combina l’activitat com a consultor amb la realització de tasques docents i d’investigació a la Delf University of Technology. També és expert en l’ús d’eines GIS i en la realització de plans ambientals, d’ordenació territorial i gestió urbana.',
	't5' => 'Pilar Gil  és enginyera de Camins, Canals i Ports per la U.P. València. Té més de 20 anys d’experiència en l’àmbit de la planificació dels transports, la mobilitat  i l’avaluació de l’Impacte Ambiental de projectes d’infrastructures i de documents urbanístics i d’ordenació territorial.  Dins d’aquests àmbits, ha participat en diversos projectes europeus INTERREG  IIIB i IIIC (REVER-Med, PIRENE I MARE).'

	);

?>