<?php
return array(

	//Carousel
	'c1' => 'URBANISME+',
	'c2' => 'MOBILITAT+',
	'c3' => 'SOSTENIBILITAT+',

	//Titles
	'h1' => 'Qui som?',
	'h2' => 'Què fem?',
	'h3' => 'Com ho fem?',

	//Text
	't1' => 'Una xarxa de professionals amb una sòlida experiència que treballem per tal d’oferir la resposta més adequada a les necessitats dels nostres clients.',
	't2' => 'Treballem en solucions per aconseguir sistemes de transport més sostenibles tant en termes mediambientals com en termes econòmics i socials.',
	't3' => 'Treballem amb i per al client, donant-li les eines i els coneixements per tal de facilitar la presa de decisions i la consolidació del seu lideratge en l’àrea de mobilitat.',

	//Buttons
	'b1' => 'Més info'


);

?>