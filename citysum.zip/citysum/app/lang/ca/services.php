<?php

	return array(

	//Header
	'h1' => 'Serveis que oferim',

	//Introduction
	'i1' => 'Les nostres intervencions parteixen d’un profund coneixement de l’estat de l’art en matèria de mobilitat, però per a nosaltres, aquest és només el punt de partida. Des de Citysum, restem oberts als darrers corrents de pensament, metodologies i tecnologies existents, per tal d’incorporar el valor afegit d’altres disciplines com a palanca d’innovació i transformació dels models de mobilitat actuals.
',

	//Services headers
	'sh1' => 'Transport públic',
	'sh2' => 'Mobilitat motoritzada',
	'sh3' => 'Mobilitat no motoritzada',
	'sh4' => 'Mobilitat professional',
	'sh5' => 'Seguretat viària',
	'sh6' => 'Polítiques transversals',
	'sh7' => 'Tecnologies de la informació',
	'sh8' => 'Participació ciutadana',

	//Public transport
	'pt1' => 'Treballem en solucions per aconseguir sistemes de transport públic social, ecològica i econòmicament més sostenibles.',
	'pt2' => 'Treballem tant des de la vessant de l’oferta com de la demanda, dissenyant sistemes de transport públic que s’adeqüin a les característiques pròpies de cada àmbit estudiat.',
	'pt3' => 'Integrem solucions multimodals i aprofitant sinèrgies entre operadors, administració i societat civil.',
	'pt4' => 'Els nostres serveis són molt variats i van des dels plans de comunicació fins a l’optimització de les operacions per tal de millorar l’eficiència energètica dels vehicles.',
	
	//Motorized mobiliy
	'mm1' => 'Busquem solucions centrades en la satisfacció de les necessitats dels ciutadans però anant més enllà d’una gestió de la mobilitat orientada exclusivament en infraestructures.',
	'mm2' => 'Ajudem a administracions públiques i a companyies privades a l’hora d’implementar solucions per al vehicle privat que contribueixin a la descarbonització del transport.',
	'mm3' => 'Els nostres serveis són variats i abasten tant mesures vinculades a la gestió (aparcament, sistemes de car-sharing, park and ride, etc.) com estudis de caràcter tecnològic (estudi d’eficiència energètica de flota, càlculs d’emissions derivades del transport, etc.).',

	//No motorized mobility
	'nmm1' => 'Considerem que els desplaçaments a peu i en bicicleta són, inqüestionablement, els modes de mobilitat més sostenibles.',
	'nmm2' => 'Creiem que fomentar aquests modes de transport passa per garantir la seguretat de vianants i ciclistes, especialment els més vulnerables: joves i gent gran.',
	'nmm3' => 'Oferim diversos serveis per tal d’adaptar l’espai urbà a les seves necessitats, tals com projectes de disseny de carrils bicis, plans de pacificació de trànsit o disseny de processos per a la implantació de camins escolars.',

	//Professional mobility
	'pm1' => 'Oferim col·laboració a ens públics i privats a l’hora de planificar aparcaments reservats, regular la circulació interna del trànsit de mercaderies o optimitzar la cadena de distribució.',
	'pm2' => 'També realitzem estudis orientats a l’ambientalització  de la mobilitat en polígons industrials.',
	'pm3' => 'Complementàriament, desenvolupem eines TIC i de sistemes d’informació per al suport a conductors de mercaderies en polígons i aparcaments de C/D.',

	//Road safe
	'rs1' => 'Desenvolupem estudis de millora del viari amb l’objectiu d’aconseguir carrers més segurs de manera que puguin ser gaudits tant per conductors d’automòbils com per vianants i ciclistes.',
	'rs2' => 'En aquests estudis es dissenyen mesures que busquen adequar les velocitats de circulació o els volums de trànsit en funció de l’especialització de la via sobre la que s’intervé.',

	//Transversal politics
	'tp1' => 'Anàlisi cost/benefici sobre polítiques ambientals orientades a la reducció de les emissions de CO2 associades al transport.',
	'tp2' => 'Anàlisis comparatius (benchmarking) sobre polítiques públiques del transport (tant des de l’àmbit de la mobilitat com del tecnològic).',
	'tp3' => 'Complementarietat dels aspectes lligats amb la mobilitat amb d’altres aspectes de les polítiques locals (promoció econòmica i social, serveis a les persones,  ocupació, etc.)',

	//IT
	'it1' => 'Desenvolupem modelitzacions i aplicacions informàtiques de suport en la presa de decisions per tal de facilitar la tasca dels responsables polítics.',
	'it2' => 'També oferim aplicacions per a mòbil i serveis web per tal d’aconseguir una millor gestió, planificació i una major comunicació i participació del ciutadà.',

	//Citizen participation
	'cp1' => 'Desenvolupament de processos de participació mitjançant eines de coaching de sala, teatre de l’oprimit, intel·ligència col·lectiva serveis web, aplicacions de telefonia mòbil.',

	);

?>