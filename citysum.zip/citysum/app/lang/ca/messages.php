<?php

	return array(

	'welcome' => 'Benvinguts a la nostra aplicació!'

	);

?>