<?php
return array(

	//Carousel
	'c1' => 'URBANISMO+',
	'c2' => 'MOVILIDAD+',
	'c3' => 'SOSTENIBILIDAD+',

	//Titles
	'h1' => 'Quiénes somos?',
	'h2' => 'Qué hacemos?',
	'h3' => 'Cómo lo hacemos?',


	//Text
	't1' => 'Somos una red de profesionales con una sólida y larga experiencia que trabaja para ofrecer a nuestros clientes la respuesta más adecuada para sus necesidades.',
	't2' => 'Trabajamos en soluciones para conseguir sistemas de transporte más sostenible tanto en términos medioambientales como en términos económicos y sociales.',
	't3' => 'Trabajamos con y para el cliente, proporcionándole las herramientas y los conocimientos para facilitar la toma de decisiones y la consolidación de su lideraje en el area de la movilidad.',

	//Buttons
	'b1' => 'Más info'
);

?>