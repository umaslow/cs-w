<?php

	return array(

	//Header
	'h1' => 'Inicio',
	'h2' => 'Proyectos',
	'h3' => 'Equipo',
	'h4' => 'Servicios',
	'h5' => 'Contacto',

	//Form
	'f1' => 'Email',
	'f2' => 'Contraseña',
	'f3' => 'Acceder'
	

	);

?>