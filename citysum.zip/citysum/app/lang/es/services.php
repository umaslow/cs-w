<?php

	return array(

	//Header
	'h1' => 'Servicios que ofrecemos',

	//Introduction
	'i1' => 'Nuestras intervenciones parten de un profundo conocimiento del estado del arte en materia de movilidad, pero para nosotros, este es sólo el punto de partida. Desde Citysum, estamos abiertos a las últimas corrientes de pensamiento, metodologías y tecnologías existentes, a fin de incorporar el valor añadido de otras disciplinas como palanca de innovación y transformación de los modelos de movilidad actuales.',

	//Services headers
	'sh1' => 'Transporte público',
	'sh2' => 'Movilidad motorizada',
	'sh3' => 'Movilidad no motorizada',
	'sh4' => 'Movilidad profesional',
	'sh5' => 'Seguridad vial',
	'sh6' => 'Políticas transversales',
	'sh7' => 'Tecnologías de la información',
	'sh8' => 'Participación ciudadana',

	//Public transport
	'pt1' => 'Trabajamos en soluciones para conseguir sistemas de transporte público social, ecológica y económicamente más sostenibles.',
	'pt2' => 'Trabajamos tanto desde la vertiente de la oferta como de la demanda, diseñando sistemas de transporte público que se adecuen a las características propias de cada ámbito estudiado.',
	'pt3' => ' Integramos soluciones multimodales y aprovechando sinergias entre operadores, administración y sociedad civil.',
	'pt4' => 'Nuestros servicios son muy variados y van desde los planes de comunicación hasta la optimización de las operaciones para mejorar la eficiencia energética de los vehículos.',
	
	//Motorized mobiliy
	'mm1' => 'Buscamos soluciones centradas en la satisfacción de las necesidades de los ciudadanos pero yendo más allá de una gestión de la movilidad orientada exclusivamente en infraestructuras. ',
	'mm2' => 'Ayudamos a administraciones públicas ya compañías privadas a la hora de implementar soluciones para el vehículo privado que contribuyan a la descarbonización del transporte.',
	'mm3' => 'Nuestros servicios son variados y abarcan tanto medidas vinculadas a la gestión (aparcamiento, sistemas de car-sharing, park and ride, etc. ) como estudios de carácter tecnológico ( estudio de eficiencia energética de flota, cálculos de emisiones derivadas del transporte, etc.',

	//No motorized mobility
	'nmm1' => 'Consideramos que los desplazamientos a pie y en bicicleta son, incuestionablemente, los modos de movilidad más sostenibles.',
	'nmm2' => 'Creemos que fomentar estos modos de transporte pasa por garantizar la seguridad de peatones y ciclistas, especialmente los más vulnerables : jóvenes y mayores.',
	'nmm3' => 'Ofrecemos diversos servicios para adaptar el espacio urbano a sus necesidades, tales como proyectos de diseño de carriles bicis, planes de pacificación de tráfico o diseño de procesos para la implantación de caminos escolares.',

	//Professional mobility
	'pm1' => 'Ofrecemos colaboración a entes públicos y privados a la hora de planificar aparcamientos reservados, regular la circulación interna del tráfico de mercancías u optimizar la cadena de distribución.',
	'pm2' => 'También realizamos estudios orientados a la ambientalización de la movilidad en polígonos industriales.',
	'pm3' => 'Complementariamente, desarrollamos herramientas TIC y de sistemas de información para el apoyo a conductores de mercancías en polígonos y aparcamientos de C / D.',

	//Road safe
	'rs1' => ' Desarrollamos estudios de mejora del viario con el objetivo de conseguir calles más seguras de manera que puedan ser disfrutados tanto por conductores de automóviles como para peatones y ciclistas.',
	'rs2' => ' En estos estudios se diseñan medidas que buscan adecuar las velocidades de circulación o los volúmenes de tráfico en función de la especialización de la vía sobre la que se interviene.',

	//Transversal politics
	'tp1' => 'Análisis coste / beneficio sobre políticas ambientales orientadas a la reducción de las emisiones de CO2 asociadas al transporte.',
	'tp2' => 'Análisis comparativos ( benchmarking ) sobre políticas públicas del transporte ( tanto desde el ámbito de la movilidad como del tecnológico ).',
	'tp3' => 'Complementariedad de los aspectos relacionados con la movilidad con otros aspectos de las políticas locales ( promoción económica y social, servicios a las personas, ocupación, etc. ).',

	//IT
	'it1' => 'Desarrollamos modelizaciones y aplicaciones informáticas de apoyo en la toma de decisiones para facilitar la tarea de los responsables políticos.',
	'it2' => 'También ofrecemos aplicaciones para móvil y servicios web para conseguir una mejor gestión, planificación y una mayor comunicación y participación del ciudadano.',

	//Citizen participation
	'cp1' => 'Desarrollo de procesos de participación mediante herramientas de coaching de sala, teatro del oprimido, inteligencia colectiva servicios web, aplicaciones de telefonía móvil. ',

	);

?>