<?php

	return array(

	'welcome' => '¡Bienvenidos a nuestra aplicación!'

	);

?>