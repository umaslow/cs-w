<?php

	return array(

	//headers
	'h1' => 'Equipo de Citysum',

	//intro
	'i1' => 'El equipo de Citysum tiene un carácter multidisciplinar y está formado por profesionales con una larga experiencia en el campo de la movilidad.',

	//text
	't1' => 'Sergi Comellas es Ingeniero Industrial con 15 años de experiencia en políticas públicas , en sostenibilidad , movilidad , medio ambiente y en eficiencia y energías renovables . También es experto en participación , inteligencia colectiva y estrategia de organizaciones . Actualmente combina tareas de consultoría en movilidad y estrategias de organizaciones y territorios con labor docente en la Escuela Elisava y ESADE . Dentro de sus ámbitos de especialización , ha organizado y participado como ponente en diversas jornadas y conferencias.',
	't2' => 'Oriol Masllovet es Licenciado en Sociología por la UB y cuenta con postgrados en Planificación y Gestión de la Movilidad y en Eficiencia Energética , ambos cursados ​​en la UPC . Su experiencia laboral se mueve sobre el vector de la planificación de la movilidad y abarca otros campos como es el de la planificación energética , el de la evaluación del impacto ambiental y el del desarrollo de modelos informatizados . Durante sus 10 años como consultor ha realizado varios proyectos tanto de ámbito nacional como internacional.',
	't3' => 'Ola Karlsson es licenciado en Urbanismo y Planificación y Master en Geografía Humana , ambas por la Universidad de Estocolmo . 17 años de experiencia en la planificación y la gestión de la movilidad en múltiples proyectos nacionales e internacionales.',
	't4' => 'Bernat Goñi es licenciado en ciencias ambientales ( UAB ) y Master in Science en Transporte , Infraestructura y Logística para la Delf University of Technology (Holanda ) y Master en Gestión y Valoración Urbana por la UPC y la Cornell University ( New York ) . Es experto en la modelización y simulación de tráfico, gestión y control del tráfico y en sistemas de transporte inteligentes, temáticas en las que combina la actividad como consultor con la realización de tareas docentes y de investigación en la Delf University of Technology. También es experto en el uso de herramientas GIS y en la realización de planes ambientales , de ordenación territorial y gestión urbana.',
	't5' => 'Pilar Gil es ingeniera de Caminos , Canales y Puertos por la UP Valencia. Tiene más de 20 años de experiencia en el ámbito de la planificación de los transportes , la movilidad y la evaluación del Impacto Ambiental de proyectos de infraestructuras y de documentos urbanísticos y de ordenación territorial . Dentro de estos ámbitos , ha participado en diversos proyectos europeos INTERREG IIIB y IIICC (REVER-Med, PIRENE I MARE).'

	);

?>