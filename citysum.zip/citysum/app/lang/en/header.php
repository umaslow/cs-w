<?php

	return array(
	//Header
	'h1' => 'Home',
	'h2' => 'Experience',
	'h3' => 'Team',
	'h4' => 'Services',
	'h5' => 'Contact',

	//Form
	'f1' => 'Email',
	'f2' => 'Password',
	'f3' => 'Sign in'


	);

?>