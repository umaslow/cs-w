<?php
return array(

	//Carousel
	'c1' => 'URBANISM+',
	'c2' => 'MOBILITY+',
	'c3' => 'SUSTAINABILITY+',

	//Titles
	'h1' => 'About us',
	'h2' => 'What we do',
	'h3' => 'How do we do',


	//Text
	't1' => 'We are a network of professionals with a strong and long experience working to offer to our customers the most appropriate response to their needs.',
	't2' => 'We work on solutions for sustainable transport systems both in environmental terms and in economic and social terms.',
	't3' => 'We work with and for our customers, providing them the tools and knowledge to facilitate decision-making and the consolidation of leadership in the mobility area.',

	//Buttons
	'b1' => 'More info'


);

?>