<?php

	return array(

	'welcome' => 'Welcome to our application'

	);
