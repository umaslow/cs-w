<?php

	return array(

	//headers
	'h1' => 'Citysum team',

	//intro
	'i1' => 'Citysum team has a multidisciplinary profile and is composed of professionals with a long expertise in the mobility field.',

	//text
	't1' => 'Sergi Comellas is an Industrial Engineer with 15 years of experience in public policy, sustainability, mobility, environment, efficiency and renewable energies. He is also an expert on participation, collective intelligence and organizational strategy. Currently he is consultant on mobiliy, organizational strategy and territory analysis and teacher at Elisava School and ESADE. He has organized and participied as a speaker in several conferences and workshops.',

	't2' => 'Oriol Masllovet has a degree in Sociology from the Univerity of Barcelona. He also has graduate degrees in Planning and Mobility Management and in Energy Efficiency, both done at the Technical University of Catalonia. His work experience moves on the vector of mobility planning and covers other areas such as energy planning, the assessment of environtment impacts and the development of computer applications. During his 10 years as a consultant he has done several projects both nationally and internationally.',

	't3' => 'Ola Karlsson has a degree in Urban and Regional Planning and a Master in Human Geography, both from the University of Stockholm. He has 17 years experience in the planning and management of mobility in many national and international projects.',

	't4' => 'Bernat Goñi has a degree in Environmental Science from Autonomous University of Barcelona and a Master in Science in Transportation, Infrastructure and Logistics from the Delft University of Technology (Netherlands). He also has a Master in Urban Management and Valuation from Cornell University (USA). He is expert in modeling and traffic simulation, traffic management and intelligent transport systems. Currently, complementarily to consulting he is developing teaching and research tasks in the Delft University of Technology.',

	't5' => 'Pilar Gil is a Civil Engineer by the Technical University of Valencia. He has over 20 years experience in the field of transport planning, mobility and environmental impact assessment for infrastructure projects. She also has experience in urban planning. Within these areas, he has participated in several European projects INTERREG IIIB and IIICC (REVER-Med, PIRENE I MARE).'

	);

?>