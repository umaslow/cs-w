<?php

	return array(

	//Header
	'h1' => 'todo',

	//Introduction
	'i1' => 'todo',

	//Services headers
	'sh1' => 'todo',
	'sh2' => 'todo',
	'sh3' => 'todo',
	'sh4' => 'todo',
	'sh5' => 'todo',
	'sh6' => 'todo',
	'sh7' => 'todo',
	'sh8' => 'todo',

	//Public transport
	'pt1' => 'todo',
	'pt2' => 'todo',
	'pt3' => 'todo',
	'pt4' => 'todo',
	
	//Motorized mobiliy
	'mm1' => 'todo',
	'mm2' => 'todo',
	'mm3' => 'todo',

	//No motorized mobility
	'nmm1' => 'todo',
	'nmm2' => 'todo',
	'nmm3' => 'todo',

	//Professional mobility
	'pm1' => 'todo',
	'pm2' => 'todo',
	'pm3' => 'todo',

	//Road safe
	'rs1' => 'todo',
	'rs2' => 'todo',

	//Transversal politics
	'tp1' => 'todo',
	'tp2' => 'todo',
	'tp3' => 'todo',

	//IT
	'it1' => 'todo',
	'it2' => 'todo',

	//Citizen participation
	'cp1' => 'todo',

	);

?>