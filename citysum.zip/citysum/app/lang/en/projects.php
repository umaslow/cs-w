<?php

	return array(

	//Header
	'h1' => 'Projects carried out',
	//Intro
	'i1' => 'Network consultants Citysum has done several projects related to the areas of mobility, transport, urban planning and sustainability in general. We present the most prominent ones.',

	//Projects
	'p1' => 'Estudi d’avaluació de la mobilitat generada relatiu al POUM de Roda de Barà',
	'p2' => 'Auditories de mobilitat a les empreses dels polígons industrials del Bages (Travel Plan Plus)',
	'p3' => 'Plan Director de Movilidad Sostenible de la isla de el Hierro',
	'p4' => 'Estudi de Mobilitat de Sant Sadurní d\'Anoia',
	'p5' => 'Herramienta avanzada para la gestión sostenible y el desarrollo del sistema de información y participación en las reservas de la biosfera',
	'p6' => 'MODEMAS - tool for assessing the energy efficiency and pollutant emissions of mobility and territorial accessibility',
	'p7' => 'ENEREM- assessment tool of energy efficiency and pollutant emissions derived from policies and regional plans',
	'p8' => 'Sustainable transport for areas with tourism through energy reduction (Starter)',
	'p9' => 'Estudi d’avaluació de la mobilitat generada relatiu al POUM de Roda de Barà',
	'p10' => 'Auditories de mobilitat a les empreses dels polígons industrials del Bages (Travel Plan Plus)',
	'p11' => 'Plan Director de Movilidad Sostenible de la isla de el Hierro',
	'p12' => 'Estudi de Mobilitat de Sant Sadurní d\'Anoia',
	'p13' => 'Herramienta avanzada para la gestión sostenible y el desarrollo del sistema de información y participación en las reservas de la biosfera',
	'p14' => 'MODEMAS - tool for assessing the energy efficiency and pollutant emissions of mobility and territorial accessibility',
	'p15' => 'ENEREM- assessment tool of energy efficiency and pollutant emissions derived from policies and regional plans',
	'p16' => 'Sustainable transport for areas with tourism through energy reduction (Starter)',

	);

?>