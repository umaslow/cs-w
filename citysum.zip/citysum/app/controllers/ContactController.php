<?php

class ContactController extends BaseController {

	protected function postEmail()
	{

		Mail::send('contact', array('contact' => 'view'), function($m)
		{
			$m->from('info@laravel.com')->to('oriolmasllovet@hotmail.com')->subject('Hey');

		});

		return View::make('contact');

	}

}
	

	