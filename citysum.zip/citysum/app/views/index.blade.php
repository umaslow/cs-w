@extends('layouts.master')

@section('languages')
<div class="container" style="padding-bottom:7px">
        <div class="row">
          <div class="col-lg-10">
          <img src="img/logoCS1.jpg"  class="img-responsive" alt="CITYSUM" height="65">
        </div>
        <div class="col-lg-2 text-right">
          <p> <a href="ca/index" style="color:#1BC331;">CA</a> <span> | </span> <a href="es/index" style="color:#1BC331;">ES</a> <span> | </span> <a href="en/index" style="color:#1BC331;">EN</a> </p>
        </div>
      </div>
    </div>
@stop

@section('navbarOptions')
    <ul class="nav navbar-nav">
      <li class="active"><a href="index"><?php echo Lang::get('header.h1') ?></a></li>
      <li><a href="team"><?php echo Lang::get('header.h3') ?></a></li>
      <li><a href="services"><?php echo Lang::get('header.h4') ?></a></li>
      <li><a href="projects"><?php echo Lang::get('header.h2') ?></a></li>
      <li><a href="contact"><?php echo Lang::get('header.h5') ?></a></li>
    </ul>
@stop

@section('content')

<div class="container">

      <!-- carousel -->
      <div class="carousel slide" id="home-carousel">

      <!--<ol class="carousel-indicators">
          <li data-target="#home-carousel" data-slide-to="0" class="active"></li>
          <li data-target="#home-carousel" data-slide-to="1"></li>
          <li data-target="#home-carousel" data-slide-to="2"></li>
          <li data-target="#home-carousel" data-slide-to="3"></li>
          <li data-target="#home-carousel" data-slide-to="4"></li>
          <li data-target="#home-carousel" data-slide-to="5"></li>
      </ol>-->

        <div class="carousel-inner">
          
          <div class="item active">
              <img src="img/u1.jpg" alt="slide2"/>
              <div style="text-align:right; right:10px; bottom:10px; padding-bottom:312px;" class="carousel-caption right">
                <!--<h1>Urbanisme</h1>-->
                <p><a class="btn btn-special" href="#" disabled="disabled"><?php echo Lang::get('home.c1')?></a></p>
                <!--<p><a class="btn btn-warning" href="#">Més informació &raquo;</a></p>-->
              </div>
          </div>

          <div class="item">
              <img src="img/m1.jpg" alt="slide1"/>
              <div style="text-align:right; right:10px; bottom:10px; padding-bottom:312px;" class="carousel-caption right">
                <!--<h1>Mobilitat</h1>-->
                <p><a class="btn btn-special" href="#" disabled="disabled"><?php echo Lang::get('home.c2')?></a></p>
                <!--<p><a class="btn btn-warning" href="#">Més informació &raquo;</a></p>-->
              </div>
          </div>
          
          <div class="item">
              <img src="img/s1.jpg" alt="slide3"/>
              <div style="text-align:right; right:10px; bottom:10px; padding-bottom:312px;" class="carousel-caption right">
                <!--<h1>Sostenibilitat</h1>-->
                <p><a class="btn btn-special" href="#" disabled="disabled"><?php echo Lang::get('home.c3')?></a></p>
              </div>
          </div>
          <!--
          <div class="item">
              <img src="img/m2.jpg" alt="slide4"/>
              <div style="text-align:right; right:20px; bottom:10px; padding-bottom:1px;" class="carousel-caption right">
                <p><a class="btn btn-special" href="#" disabled="disabled">MOBILITAT</a></p>
              </div>
          </div>
          <div class="item">
              <img src="img/u2.jpg" alt="slide5"/>
              <div style="text-align:right; right:20px; bottom:10px; padding-bottom:1px;" class="carousel-caption right">
                <p><a class="btn btn-special" href="#" disabled="disabled">MOBILITAT<br>+<br>URBANISME<br></a></p>
              </div>
          </div>
          <div class="item">
              <img src="img/s2.jpg" alt="slide6"/>
              <div style="text-align:right; right:20px; bottom:10px; padding-bottom:1px;" class="carousel-caption right">
                <p><a class="btn btn-special" href="#" disabled="disabled">MOBILITAT<br>+<br>URBANISME<br>+<br>SOSTENIBILITAT</a></p>
              </div>
          </div>
        -->
        </div> <!-- carousel - inner -->

        <!--<a class="carousel-control left" href="#home-carousel" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></a>
        <a class="carousel-control right" href="#home-carousel" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></a>-->

      </div> <!-- carousel -->

      <!-- Example row of columns -->
      <div class="container" style="padding-top:20px;">
        <div class="row">
            <div class="col-lg-4">
                  <h2><?php echo Lang::get('home.h1')?></h2>
                  <p><?php echo Lang::get('home.t1')?></p>
                  <p><a class="btn btn-sm btn-success" href="team"><?php echo Lang::get('home.b1')?> &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                  <h2><?php echo Lang::get('home.h2')?></h2>
                  <p><?php echo Lang::get('home.t2')?></p>
                  <p><a class="btn btn-sm btn-success" href="projects"><?php echo Lang::get('home.b1')?> &raquo;</a></p>
           </div>
            <div class="col-lg-4">
                  <h2><?php echo Lang::get('home.h3')?></h2>
                  <p><?php echo Lang::get('home.t3')?></p>
                  <p><a class="btn btn-sm btn-success" href="services"><?php echo Lang::get('home.b1')?> &raquo;</a></p>
            </div>
      </div>
    </div>

@stop

@section('footer')

      <footer class="container" style="padding-top:65px;">
        <hr> 
        <p>&copy; Citysum 2013</p>
      </footer>

@stop