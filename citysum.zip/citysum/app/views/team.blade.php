@extends('layouts.master')

@section('languages')
<div class="container" style="padding-bottom:7px">
        <div class="row">
          <div class="col-lg-10">
          <img src="img/logoCS1.jpg"  class="img-responsive"  alt="CITYSUM" height="65">
        </div>
        <div class="col-lg-2 text-right">
          <p> <a href="ca/team" style="color:#1BC331;">CA</a> <span> | </span> <a href="es/team" style="color:#1BC331;">ES</a> <span> | </span> <a href="en/team" style="color:#1BC331;">EN</a> </p>
        </div>
      </div>
    </div>
@stop

@section('navbarOptions')
    <ul class="nav navbar-nav">
      <li><a href="index"><?php echo Lang::get('header.h1') ?></a></li>
      <li class="active"><a href="team"><?php echo Lang::get('header.h3') ?></a></li>
      <li><a href="services"><?php echo Lang::get('header.h4') ?></a></li>
      <li><a href="projects"><?php echo Lang::get('header.h2') ?></a></li>
      <li><a href="contact"><?php echo Lang::get('header.h5') ?></a></li>
    </ul>
@stop


@section('content')

<!-- Main hero unit for a primary marketing message or call to action -->

  <div class="container">

     <div class="row">
        <div class="col-lg-12">
          <img src="img/puzzle2.jpg" class="img-responsive">
        </div>
      </div>

     <div class="row">
        <div class="col-lg-12">
       <h2></h2>
        </div>
     </div>

     <div style="padding-top:30px" class="container">
   
     <div class="row">

        <div class="col-lg-4">
          <h3><?php echo Lang::get('team.h1')?></h3>
          <p><?php echo Lang::get('team.i1')?></p>
        </div>



        <div class="col-lg-8">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#scomellas" data-toggle="tab" style="color:black;"><h5>Sergi Comellas</h5></a><li>
            <li><a href="#omasllovet" data-toggle="tab" style="color:black;"><h5>Oriol Masllovet</h5></a><li>
            <li><a href="#okarlsson" data-toggle="tab" style="color:black;"><h5>Ola Karlsson</h5></a><li>
            <li><a href="#bgonyi" data-toggle="tab" style="color:black;"><h5>Bernat Goñi</h5></a><li>
            <li><a href="#pgil" data-toggle="tab" style="color:black;"><h5>Pilar Gil</h5></a><li>
          </ul>
          <div class="tab-content">
          <div class="tab-pane active" id="scomellas">
              <div class="container">
                <div class="row" style="padding-top:20px;">
                  <div class="col-lg-2" style="left:20px;">
                  <img src="img/scomellas.jpg" alt="placeholder" class="img-responsive"/>
                  </div>
                      <div class="col-lg-10">
                          <p><?php echo Lang::get('team.t1')?><br><br></p>
                      </div>
                    </div>
                </div>
            </div>
          <div class="tab-pane" id="omasllovet">
              <div class="container">
                <div class="row" style="padding-top:20px;">
                  <div class="col-lg-2" style="left:20px;">
                  <img src="img/omasllovet.jpg" alt="placeholder" class="pull-left-thumbnail img-responsive" />
                  </div>
                      <div class="col-lg-10">
                          <p><?php echo Lang::get('team.t2')?><br><br></p>
                      </div>
                    </div>
                </div>
          </div>
          <div class="tab-pane" id="okarlsson">
              <div class="container">
                <div class="row" style="padding-top:20px;">
                  <div class="col-lg-2" style="left:20px;">
                  <img src="http://placehold.it/70x110" alt="placeholder" class="pull-left-thumbnail img-responsive" />
                  </div>
                      <div class="col-lg-10">
                          <p><?php echo Lang::get('team.t3')?><br><br><br><br><br></p>
                      </div>
                    </div>
                </div>
          </div>
          <div class="tab-pane" id="bgonyi">
              <div class="container">
                <div class="row" style="padding-top:20px;">
                  <div class="col-lg-2" style="left:20px;">
                  <img src="http://placehold.it/70x110" alt="placeholder" class="pull-left-thumbnail img-responsive" />
                  </div>
                      <div class="col-lg-10">
                          <p><?php echo Lang::get('team.t4')?></p>
                      </div>
                    </div>
                </div>
          </div>
          <div class="tab-pane" id="pgil">
              <div class="container">
                <div class="row" style="padding-top:20px;">
                  <div class="col-lg-2" style="left:20px;">
                  <img src="http://placehold.it/70x110" alt="placeholder" class="pull-left-thumbnail img-responsive" />
                  </div>
                      <div class="col-lg-10">
                          <p><?php echo Lang::get('team.t5')?><br><br><br></p>
                      </div>
                    </div>
                </div>
          </div>
          </div>
        </div>
      </div>
    </div>

@stop


@section('footer')

      <footer class="container" style="padding-top:67px;">
        <hr> 
        <p>&copy; Citysum 2013</p>
      </footer>

@stop