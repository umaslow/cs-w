@extends('layouts.master')

@section('languages')
<div class="container" style="padding-bottom:7px">
        <div class="row">
          <div class="col-lg-10">
          <img src="img/logoCS1.jpg"  class="img-responsive"  alt="CITYSUM" height="65">
        </div>
        <div class="col-lg-2 text-right">
          <p> <a href="ca/contact" style="color:#1BC331;">CA</a> <span> | </span> <a href="es/contact" style="color:#1BC331;">ES</a> <span> | </span> <a href="en/contact" style="color:#1BC331;">EN</a> </p>
        </div>
      </div>
    </div>
@stop

@section('navbarOptions')
    <ul class="nav navbar-nav">
      <li><a href="index"><?php echo Lang::get('header.h1') ?></a></li>
      <li><a href="team"><?php echo Lang::get('header.h3') ?></a></li>
      <li><a href="services"><?php echo Lang::get('header.h4') ?></a></li>
      <li><a href="projects"><?php echo Lang::get('header.h2') ?></a></li>
      <li class="active"><a href="contact"><?php echo Lang::get('header.h5') ?></a></li>
    </ul>
@stop

@section('content')

  <div class="container">
      
      <div class="row">
        <div class="col-lg-12">          
          <img src="img/com.jpg" class="img-responsive"><!--"http://placehold.it/1140x300"-->
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <h2></h2>
        </div>
      </div>


      <div class="container">
      <div class="row">

        <div class="col-lg-3">
          <h3>Contacte</h3>
          <p><b>Citysum - Xarxa de consultors</b><br> c/ Sant Antoni Maria Claret 357 <br> 08027 Barcelona<br>T. +34 666 666 666<br>info@citysum.com</p>
        </div>

        <div class="container">
        <div class="row">

        <div class="col-lg-9 well">

          <div class="container">
          <div class="row">
          <div class="col-lg-6">
            
            
            
              <form name="info" class="form-group" method="post">
            
                <div class="input-group">

                  <p><input type="text" name="name" placeholder="Nom" class="form-control"></p>
  
                  <p><input type="text" name="email" placeholder="Email" class="form-control"></p>

                  <p><textarea form="info" id="consulta" rows="5" cols="80" class="form-control" placeholder="Text de consulta"></textarea></p>

                  <p><button type="submit" class="btn btn-success btn-sm" action="" value="Enviar">Enviar</button></p>
                  
                </div>
                             
              </form>

            

          </div>
          </div>
          </div>

           </div>

          </div>

        </div>

        </div>

      </div>

  </div>

  </div>

  
    

@stop



@section('footer')

      <footer class="container" style="padding-top:0px;">
        <hr> 
        <p>&copy; Citysum 2013</p>
      </footer>

@stop