
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>&copy; Citysum website | 2013</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 10px;
        padding-bottom: 40px;
      }
    </style>
    
    <link href="css/bootstrap-responsive.css" rel="stylesheet">

  </head>

  <body>

   <body style="">

   <div class="navbar-wrapper">
    
      @yield('languages')
	    
		
		<div class="container">

	    <div class="navbar navbar-inverse navbar-static-top">
	      <div class="container">
	        <div class="navbar-header">
	          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	            <span class="icon-bar"></span>
	          </button>
	          <a class="navbar-brand" href="#"></a>
	        </div>
	        <div class="navbar-collapse collapse">
              @yield('navbarOptions')
	          <!--<form class="navbar-form navbar-right">
	            <div class="form-group" >
	              <input type="text" placeholder=<?php echo Lang::get('header.f1')?> class="form-control input-sm">
	            </div>
	            <div class="form-group">
	              <input type="password" placeholder=<?php echo Lang::get('header.f2')?> class="form-control input-sm">
	            </div>
	            <button type="submit" class="btn btn-sm btn-success"><?php echo Lang::get('header.f3')?></button>
	          </form>-->
	        </div><!--/.navbar-collapse -->
	      </div>

	      </div>
	        
	      </div>

    </div>


    
    @yield('content')
    
    
    @yield('footer')
      

    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-2.0.3.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script>

      $(document).ready(function()
      {
        $('.carousel').carousel();
      });

    </script>

  </body>
  
</html>



