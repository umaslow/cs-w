@extends('layouts.master')

@section('languages')
<div class="container" style="padding-bottom:7px">
        <div class="row">
          <div class="col-lg-10">
          <img src="img/logoCS1.jpg"  class="img-responsive"  alt="CITYSUM" height="65">
        </div>
        <div class="col-lg-2 text-right">
          <p> <a href="ca/services" style="color:#1BC331;">CA</a> <span> | </span> <a href="es/services" style="color:#1BC331;">ES</a> <span> | </span> <a href="en/services" style="color:#1BC331;">EN</a> </p>
        </div>
      </div>
    </div>
@stop

@section('navbarOptions')
    <ul class="nav navbar-nav">
      <li><a href="index"><?php echo Lang::get('header.h1')?></a></li>
      <li><a href="team"><?php echo Lang::get('header.h3') ?></a></li>
      <li class="active"><a href="services"><?php echo Lang::get('header.h4') ?></a></li>
      <li><a href="projects"><?php echo Lang::get('header.h2') ?></a></li>
      <li><a href="contact"><?php echo Lang::get('header.h5') ?></a></li>
    </ul>
@stop

@section('content')

    
    <div class="container">

      <div class="row">
        <div class="col-lg-12">
          <!--<img src="http://placehold.it/1140x300">-->
          <!-- carousel -->
          <div class="carousel" data-interval="false" id="home-carousel">

          <!--<ol class="carousel-indicators">
              <li data-target="#home-carousel" data-slide-to="0" class="active"></li>
              <li data-target="#home-carousel" data-slide-to="1"></li>
              <li data-target="#home-carousel" data-slide-to="2"></li>
              <li data-target="#home-carousel" data-slide-to="3"></li>
              <li data-target="#home-carousel" data-slide-to="4"></li>
              <li data-target="#home-carousel" data-slide-to="5"></li>
              <li data-target="#home-carousel" data-slide-to="6"></li>
              <li data-target="#home-carousel" data-slide-to="7"></li>
          </ol>-->

            <div class="carousel-inner">
              <div class="item active">
                  <img src="img/pt.jpg" alt="slide1"/>
                  <!-- <div class="carousel-caption">
                    <h3>Cycling</h3>
                    <p><a class="btn btn-warning" href="#">Més informació &raquo;</a></p>
                  </div>-->
              </div>
              <div class="item">
                  <img src="img/mm.jpg" alt="slide2"/>
              </div>
              <div class="item">
                  <img src="img/nmm.jpg" alt="slide3"/>
              </div>
              <div class="item">
                  <img src="img/mp.jpg" alt="slide4"/>
              </div>
              <div class="item">
                  <img src="img/sv.jpg" alt="slide5"/>
              </div>
              <div class="item">
                  <img src="img/tp.jpg" alt="slide6"/>
              </div>
              <div class="item">
                  <img src="img/tic.jpg" alt="slide7"/>
              </div>
              <div class="item">
                  <img src="img/cp.jpg" alt="slide8"/>
              </div>
            </div> <!-- carousel - inner -->

            <!--<a class="carousel-control left" href="#home-carousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></a>
            <a class="carousel-control right" href="#home-carousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></a>-->

          </div> <!-- carousel -->
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <h2></h2>
        </div>
      </div>

      <div class="row">
        
        <div class="col-lg-12">
          <h3><?php echo Lang::get('services.h1')?></h3>
        </div>

        <div class="col-lg-12">
          <p><?php echo Lang::get('services.i1')?></p>
        </div>

      </div>

      <!--accordion-->

      <div style="padding-top:10px" class="row">

        <div class="container" style="max-height:100px;">

        <div style="float:left;" class="panel-group col-lg-6" id="accordion1">

          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="0">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#transpublic">
                  <?php echo Lang::get('services.sh1')?>
                </a>
              </h4>
            </div>
            <div id="transpublic" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.pt1')?></li>
                    <li><?php echo Lang::get('services.pt2')?></li>
                    <li><?php echo Lang::get('services.pt3')?></li>
                    <li><?php echo Lang::get('services.pt4')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="1">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#mobmotor">
                  <?php echo Lang::get('services.sh2')?>
                </a>
              </h4>
            </div>
            <div id="mobmotor" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.mm1')?></li>
                    <li><?php echo Lang::get('services.mm2')?></li>
                    <li><?php echo Lang::get('services.mm3')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="2">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#mobnomotor">
                  <?php echo Lang::get('services.sh3')?>
                </a>
              </h4>
            </div>
            <div id="mobnomotor" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.nmm1')?></li>
                    <li><?php echo Lang::get('services.nmm2')?></li>
                    <li><?php echo Lang::get('services.nmm3')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="3">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#mobprof">
                  <?php echo Lang::get('services.sh4')?>
                </a>
              </h4>
            </div>
            <div id="mobprof" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.pm1')?></li>
                    <li><?php echo Lang::get('services.pm2')?></li>
                    <li><?php echo Lang::get('services.pm3')?></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div style="float:left;" class="panel-group col-lg-6" id="accordion2">
          

          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="4">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#segvia">
                  <?php echo Lang::get('services.sh5')?>
                </a>
              </h4>
            </div>
            <div id="segvia" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.rs1')?></li>
                    <li><?php echo Lang::get('services.rs2')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="5">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#poltrans">
                  <?php echo Lang::get('services.sh6')?>
                </a>
              </h4>
            </div>
            <div id="poltrans" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.tp1')?></li>
                    <li><?php echo Lang::get('services.tp2')?></li>
                    <li><?php echo Lang::get('services.tp3')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="6">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#tic">
                  <?php echo Lang::get('services.sh7')?>
                </a>
              </h4>
            </div>
            <div id="tic" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.it1')?></li>
                    <li><?php echo Lang::get('services.it2')?></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title" data-target="#home-carousel" data-slide-to="7">
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#particip">
                  <?php echo Lang::get('services.sh8')?>
                </a>
              </h4>
            </div>
            <div id="particip" class="panel-collapse collapse">
              <div class="panel-body">
                <ul>
                    <li><?php echo Lang::get('services.cp1')?></li>
                </ul>
              </div>
            </div>
          </div>
      
          </div> <!-- fi de segona columna -->

        </div>       
      </div>
     
      <!--accordion-->


@stop



@section('footer')

      <footer class="container" style="padding-top:60px;">
        <hr> 
        <p>&copy; Citysum 2013</p>
      </footer>

@stop