@extends('layouts.master')

@section('languages')
<div class="container" style="padding-bottom:7px">
        <div class="row">
          <div class="col-lg-10">
          <img src="img/logoCS1.jpg"  class="img-responsive"  alt="CITYSUM" height="65">
        </div>
        <div class="col-lg-2 text-right">
          <p> <a href="ca/projects" style="color:#1BC331;">CA</a> <span> | </span> <a href="es/projects" style="color:#1BC331;">ES</a> <span> | </span> <a href="en/projects" style="color:#1BC331;">EN</a> </p>
        </div>
      </div>
    </div>
@stop

@section('navbarOptions')
    <ul class="nav navbar-nav">
      <li><a href="index"><?php echo Lang::get('header.h1') ?></a></li>
      <li><a href="team"><?php echo Lang::get('header.h3') ?></a></li>
      <li><a href="services"><?php echo Lang::get('header.h4') ?></a></li>
      <li class="active"><a href="projects"><?php echo Lang::get('header.h2') ?></a></li>
      <li><a href="contact"><?php echo Lang::get('header.h5') ?></a></li>
    </ul>
@stop

@section('content')

    
    <div class="container">

      <div class="row">
        <div class="col-lg-12">
          <img src="img/projects.jpg" alt="slide1" class="img-responsive"  />
          <!-- <img src="http://placehold.it/1140x300"> -->
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <h2></h2>
        </div>
      </div>

      <div class="container">
      <div class="row">

        <div class="col-lg-4">
          <h3><?php echo Lang::get('projects.h1')?></h3>
          <p><?php echo Lang::get('projects.i1')?></p>
        </div>

        <div style="overflow: auto; max-height: 300px;" class="col-lg-8">
          <table class="table table-striped table-bordered">
          <!--<thead>
            <th>Nom del projecte</th>
          </thead>-->
          <tbody class="h6">
            <tr>
              <td><?php echo Lang::get('projects.p1')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p2')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p3')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p4')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p5')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p6')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p7')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p8')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p9')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p10')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p11')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p12')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p13')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p14')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p15')?></td>
            </tr>
            <tr>
              <td><?php echo Lang::get('projects.p16')?></td>
            </tr>
            
          </tbody>
          </table>        
        </div>

      </div>

      </div>

    </div>

@stop



@section('footer')

      <footer class="container" style="padding-top:25px;">
        <hr> 
        <p>&copy; Citysum 2013</p>
      </footer>

@stop